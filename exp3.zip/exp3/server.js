const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware to parse incoming JSON data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve the HTML signup page
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/signup.html');
});

// Handle the POST request for signup
app.post('/signup', (req, res) => {
    const { username, password, gender, email } = req.body;

    // Create a user object
    const newUser = {
        username,
        password,
        gender,
        email
    };

    // Read existing data from the JSON file
    fs.readFile('users.json', 'utf-8', (err, data) => {
        if (err) {
            console.error('Error reading file:', err);
            return res.status(500).send('Internal Server Error');
        }

        let users = [];
        if (data) {
            users = JSON.parse(data);
        }

        // Add the new user to the list
        users.push(newUser);

        // Write the updated user data back to the JSON file
        fs.writeFile('users.json', JSON.stringify(users, null, 2), (err) => {
            if (err) {
                console.error('Error writing file:', err);
                return res.status(500).send('Internal Server Error');
            }

            res.send('User successfully registered!');
        });
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
